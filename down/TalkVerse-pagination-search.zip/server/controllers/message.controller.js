import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/apiReq.js";
import { ApiResponse } from "../utils/apiRes.js";

import { Message } from "../models/message.model.js";
import { Conversation } from "../models/conversation.model.js";
import { Connection } from "../models/connection.model.js";

import { uploadOnCloudinary } from "../utils/cloudinary.js";


const getMessages = asyncHandler(async (req, res) => {
    const { conversationId } = req.params;

    const page = Math.max(
        parseInt(req.query.page) || 1,
        1
    );

    const limit = Math.min(
        Math.max(parseInt(req.query.limit) || 30, 1),
        100
    );

    const conversation = await Conversation.findById(
        conversationId
    );

    if (!conversation) {
        throw new ApiError(
            404,
            "Conversation not found"
        );
    }

    const isMember = conversation.members.some(
        member =>
            member.toString() === req.user._id.toString()
    );

    if (!isMember) {
        throw new ApiError(
            403,
            "You are not a member of this conversation"
        );
    }

    const skip = (page - 1) * limit;

    const messages = await Message.find({
        conversation: conversationId
    })
        .populate(
            "sender",
            "username fullname avatar"
        )
        .populate(
            "conversation",
            "type members"
        ).populate({
            path: "replyTo",
            select: "content type media sender deleted isEdited",
            populate: {
                path: "sender",
                select: "username fullname avatar"
            }
        })
        .sort({
            createdAt: -1
        })
        .skip(skip)
        .limit(limit);

    const totalMessages = await Message.countDocuments({
        conversation: conversationId
    });

    return res.status(200).json(
        new ApiResponse(
            200,
            {
                messages,
                pagination: {
                    page,
                    limit,
                    totalMessages,
                    totalPages: Math.ceil(
                        totalMessages / limit
                    ),
                    hasMore:
                        page * limit < totalMessages
                }
            },
            "Messages fetched successfully"
        )
    );
});


const searchMessages = asyncHandler(async (req, res) => {
    const { conversationId } = req.params;
    const query = String(req.query.q || "").trim();
    const limit = Math.min(Math.max(parseInt(req.query.limit) || 50, 1), 100);

    if (!query) {
        return res.status(200).json(new ApiResponse(200, { messages: [], total: 0 }, "Search results fetched successfully"));
    }

    const conversation = await Conversation.findById(conversationId).select("members");
    if (!conversation) throw new ApiError(404, "Conversation not found");

    const isMember = conversation.members.some(
        (member) => member.toString() === req.user._id.toString()
    );
    if (!isMember) throw new ApiError(403, "You are not a member of this conversation");

    const safeQuery = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const filter = {
        conversation: conversationId,
        deleted: { $ne: true },
        type: "text",
        content: { $regex: safeQuery, $options: "i" },
    };

    const [messages, total] = await Promise.all([
        Message.find(filter)
            .populate("sender", "username fullname avatar")
            .populate("conversation", "type members")
            .populate({
                path: "replyTo",
                select: "content type media sender deleted isEdited",
                populate: { path: "sender", select: "username fullname avatar" },
            })
            .sort({ createdAt: -1 })
            .limit(limit),
        Message.countDocuments(filter),
    ]);

    const searchResults = await Promise.all(
        messages.map(async (message) => {
            const newerCount = await Message.countDocuments({
                conversation: conversationId,
                $or: [
                    { createdAt: { $gt: message.createdAt } },
                    { createdAt: message.createdAt, _id: { $gt: message._id } },
                ],
            });

            return {
                ...message.toObject(),
                messagePage: Math.floor(newerCount / limit) + 1,
            };
        })
    );

    return res.status(200).json(
        new ApiResponse(200, { messages: searchResults, total }, "Search results fetched successfully")
    );
});


const sendMessage = asyncHandler(async (req, res) => {
    const { conversationId } = req.params;
    const { content } = req.body;

    if (!content?.trim()) {
        throw new ApiError(
            400,
            "Message content is required"
        );
    }

    const conversation = await Conversation.findById(
        conversationId
    );

    if (!conversation) {
        throw new ApiError(
            404,
            "Conversation not found"
        );
    }

    const isMember = conversation.members.some(
        member =>
            member.toString() === req.user._id.toString()
    );

    if (!isMember) {
        throw new ApiError(
            403,
            "You are not a member of this conversation"
        );
    }

    // Check block only for direct conversations
    if (conversation.type === "direct") {

        const otherUser = conversation.members.find(
            member =>
                member.toString() !==
                req.user._id.toString()
        );

        const blocked = await Connection.findOne({
            status: "blocked",
            $or: [
                {
                    sender: req.user._id,
                    receiver: otherUser
                },
                {
                    sender: otherUser,
                    receiver: req.user._id
                }
            ]
        });

        if (blocked) {
            throw new ApiError(
                403,
                "You cannot send messages to this user"
            );
        }
    }

    const message = await Message.create({
        conversation: conversationId,
        sender: req.user._id,
        type: "text",
        content: content.trim()
    });

    conversation.lastMessage = message._id;

    await conversation.save();

    const populatedMessage = await Message.findById(
        message._id
    ).populate(
        "sender",
        "username fullname avatar"
    );

    return res.status(201).json(
        new ApiResponse(
            201,
            populatedMessage,
            "Message sent successfully"
        )
    );
});


const deleteMessage = asyncHandler(async (req, res) => {
    const { messageId } = req.params;

    const message = await Message.findById(messageId);

    if (!message) {
        throw new ApiError(
            404,
            "Message not found"
        );
    }

    if (
        message.sender.toString() !==
        req.user._id.toString()
    ) {
        throw new ApiError(
            403,
            "You can only delete your own messages"
        );
    }

    // Soft-delete so the deleted state is consistent for every participant
    // and a later message fetch cannot resurrect the original content.
    await Message.findByIdAndUpdate(messageId, {
        $set: {
            deleted: true,
            content: "",
            isEdited: false,
        },
        $unset: {
            attachments: "",
            replyTo: "",
        },
    });

    // If deleted message was lastMessage, move the preview to the latest
    // non-deleted message.
    const conversation = await Conversation.findById(message.conversation);

    if (conversation?.lastMessage?.toString() === messageId) {
        const previousMessage = await Message.findOne({
            conversation: message.conversation,
            deleted: { $ne: true },
        }).sort({ createdAt: -1 });

        conversation.lastMessage = previousMessage?._id || null;
        await conversation.save();
    }

    return res.status(200).json(
        new ApiResponse(
            200,
            {},
            "Message deleted successfully"
        )
    );
});

const sendMediaMessage = asyncHandler(async (req, res) => {
    const { conversationId } = req.params;

    const conversation = await Conversation.findById(
        conversationId
    );

    if (!conversation) {
        throw new ApiError(
            404,
            "Conversation not found"
        );
    }

    const isMember = conversation.members.some(
        member =>
            member.toString() === req.user._id.toString()
    );

    if (!isMember) {
        throw new ApiError(
            403,
            "You are not a member of this conversation"
        );
    }

    if (conversation.type === "direct") {

        const otherUser = conversation.members.find(
            member =>
                member.toString() !==
                req.user._id.toString()
        );

        const blocked = await Connection.findOne({
            status: "blocked",
            $or: [
                {
                    sender: req.user._id,
                    receiver: otherUser
                },
                {
                    sender: otherUser,
                    receiver: req.user._id
                }
            ]
        });

        if (blocked) {
            throw new ApiError(
                403,
                "You cannot send messages to this user"
            );
        }
    }


    if (!req.file) {
        throw new ApiError(
            400,
            "Media file is required"
        );
    }

    const uploadedFile = await uploadOnCloudinary(
        req.file.path,
        `NexTalk/Chat/${conversationId}`
    );

    if (!uploadedFile) {
        throw new ApiError(
            500,
            "Failed to upload media"
        );
    }

    let messageType;

    if (req.file.mimetype.startsWith("image/")) {
        messageType = "image";
    } else if (req.file.mimetype.startsWith("video/")) {
        messageType = "video";
    } else if (req.file.mimetype.startsWith("audio/")) {
        messageType = "audio";
    } else {
        // Generic file uploads are intentionally disabled for now.
        // Keep the chat media surface limited to images, videos and audio.
        throw new ApiError(400, "Only images, videos and audio are supported");
    }

    const message = await Message.create({
        conversation: conversationId,
        sender: req.user._id,
        type: messageType,
        media: {
            url: uploadedFile.secure_url,
            publicId: uploadedFile.public_id,
            fileName: req.file.originalname,
            fileSize: req.file.size,
            mimeType: req.file.mimetype
        }
    });

    conversation.lastMessage = message._id;

    await conversation.save();

    const populatedMessage = await Message.findById(
        message._id
    ).populate(
        "sender",
        "username fullname avatar"
    );

    return res.status(201).json(
        new ApiResponse(
            201,
            populatedMessage,
            "Media message sent successfully"
        )
    );
})


export {
    getMessages,
    searchMessages,
    sendMessage,
    deleteMessage,
    sendMediaMessage
};