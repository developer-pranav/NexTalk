import { Bell, MessageSquare, Search } from "lucide-react";
import Avatar from "./Avatar";
import { useAuth } from "../context/AuthContext";

export default function IconRail({ active = "chats", onChangeTab, onOpenProfile, requestCount = 0 }) {
    const { user } = useAuth();
    const items = [
        { key: "chats", label: "Chats", icon: MessageSquare },
        { key: "search", label: "Search", icon: Search },
        { key: "requests", label: "Requests", icon: Bell },
    ];

    return (
        <div className="flex h-full w-20 shrink-0 flex-col items-center justify-between py-5">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl text-[15px] font-semibold" style={{ background: "var(--accent)", color: "var(--accent-text)", boxShadow: "var(--shadow-sm)" }}>C</div>
            <div className="flex flex-col items-center gap-2 rounded-full px-2 py-3" style={{ background: "var(--surface)", boxShadow: "var(--shadow-md)", border: "1px solid var(--border)" }}>
                {items.map(({ key, label, icon: Icon }) => {
                    const isActive = active === key;
                    return (
                        <button key={key} onClick={() => onChangeTab?.(key)} className="relative grid h-10 w-10 place-items-center rounded-full transition-all duration-150 active:scale-90" style={{ background: isActive ? "var(--accent-soft)" : "transparent", color: isActive ? "var(--accent)" : "var(--text-faint)" }} aria-label={label}>
                            <Icon size={18} strokeWidth={isActive ? 2.3 : 2} />
                            {key === "requests" && requestCount > 0 && (
                                <span className="absolute -right-1 -top-1 min-w-[17px] h-[17px] px-1 rounded-full bg-red-500 text-white text-[9px] font-bold leading-[17px] text-center">
                                    {requestCount > 99 ? "99+" : requestCount}
                                </span>
                            )}
                        </button>
                    );
                })}
                <div className="my-1 h-px w-6" style={{ background: "var(--border)" }} />
                <button onClick={onOpenProfile} className="rounded-full transition-transform active:scale-90" aria-label="Open profile">
                    <Avatar name={user?.fullname || user?.name} initials={user?.initials} src={user?.avatar} color="var(--accent)" size="sm" />
                </button>
            </div>
        </div>
    );
}
