import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import {
    Check,
    CheckCheck,
    UserRound,
    Play,
    Pause,
    Volume2,
    VolumeX,
    X,
} from "lucide-react";

const LONG_PRESS_MS = 450;
const LONG_PRESS_MOVE_TOLERANCE = 10;


function formatDuration(seconds) {
    if (!Number.isFinite(seconds)) return "0:00";
    const total = Math.max(0, Math.floor(seconds));
    const minutes = Math.floor(total / 60);
    const secs = String(total % 60).padStart(2, "0");
    return `${minutes}:${secs}`;
}

function MediaProgress({ value, onChange }) {
    return (
        <input
            type="range"
            min="0"
            max="100"
            step="0.1"
            value={Number.isFinite(value) ? value : 0}
            onChange={onChange}
            className="media-range w-full"
            aria-label="Media progress"
        />
    );
}

function CustomAudioPlayer({ src }) {
    const audioRef = useRef(null);
    const [playing, setPlaying] = useState(false);
    const [current, setCurrent] = useState(0);
    const [duration, setDuration] = useState(0);
    const [volume, setVolume] = useState(1);

    useEffect(() => {
        const audio = audioRef.current;
        if (!audio) return;
        const onLoaded = () => setDuration(audio.duration || 0);
        const onTime = () => setCurrent(audio.currentTime || 0);
        const onEnded = () => setPlaying(false);
        audio.addEventListener("loadedmetadata", onLoaded);
        audio.addEventListener("timeupdate", onTime);
        audio.addEventListener("ended", onEnded);
        return () => {
            audio.removeEventListener("loadedmetadata", onLoaded);
            audio.removeEventListener("timeupdate", onTime);
            audio.removeEventListener("ended", onEnded);
        };
    }, []);

    const toggle = async () => {
        const audio = audioRef.current;
        if (!audio) return;
        if (audio.paused) {
            try { await audio.play(); setPlaying(true); } catch {}
        } else {
            audio.pause();
            setPlaying(false);
        }
    };

    const seek = (e) => {
        const next = Number(e.target.value);
        const audio = audioRef.current;
        if (!audio || !duration) return;
        audio.currentTime = (next / 100) * duration;
        setCurrent(audio.currentTime);
    };

    return (
        <div className="mb-1 flex min-w-[245px] max-w-[330px] items-center gap-2 rounded-2xl px-2.5 py-2" style={{ background: "color-mix(in srgb, var(--surface-2) 88%, transparent)" }}>
            <audio ref={audioRef} src={src} preload="metadata" />
            <button type="button" onClick={toggle} className="grid h-9 w-9 shrink-0 place-items-center rounded-full" style={{ background: "var(--accent)", color: "var(--accent-text)" }} aria-label={playing ? "Pause audio" : "Play audio"}>
                {playing ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" className="ml-0.5" />}
            </button>
            <div className="min-w-0 flex-1">
                <MediaProgress value={duration ? (current / duration) * 100 : 0} onChange={seek} />
                <div className="mt-0.5 flex items-center justify-between text-[10px] opacity-70">
                    <span>{formatDuration(current)}</span>
                    <span>{formatDuration(duration)}</span>
                </div>
            </div>
            <button
                type="button"
                onClick={() => {
                    const next = volume > 0 ? 0 : 1;
                    setVolume(next);
                    if (audioRef.current) audioRef.current.volume = next;
                }}
                className="grid h-8 w-8 shrink-0 place-items-center rounded-full transition-opacity hover:opacity-80"
                aria-label={volume > 0 ? "Mute audio" : "Unmute audio"}
            >
                {volume > 0 ? <Volume2 size={15} /> : <VolumeX size={15} />}
            </button>
        </div>
    );
}

function MediaViewer({ media, type, onClose }) {
    const videoRef = useRef(null);
    const [playing, setPlaying] = useState(false);
    const [current, setCurrent] = useState(0);
    const [duration, setDuration] = useState(0);
    const [muted, setMuted] = useState(false);
    const [closing, setClosing] = useState(false);

    useEffect(() => {
        document.body.style.overflow = "hidden";
        return createPortal(
        () => {
            document.body.style.overflow = "";
        };
    }, []);

    useEffect(() => {
        if (type !== "video") return;
        const video = videoRef.current;
        if (!video) return;

        const onLoaded = () => setDuration(Number.isFinite(video.duration) ? video.duration : 0);
        const onTime = () => setCurrent(video.currentTime || 0);
        const onEnded = () => setPlaying(false);

        video.addEventListener("loadedmetadata", onLoaded);
        video.addEventListener("timeupdate", onTime);
        video.addEventListener("ended", onEnded);

        return createPortal(
        () => {
            video.removeEventListener("loadedmetadata", onLoaded);
            video.removeEventListener("timeupdate", onTime);
            video.removeEventListener("ended", onEnded);
        };
    }, [type]);

    useEffect(() => {
        const onKey = (e) => {
            if (e.key === "Escape") handleClose();
        };
        window.addEventListener("keydown", onKey);
        return () => window.removeEventListener("keydown", onKey);
    });

    const handleClose = () => {
        if (closing) return;
        setClosing(true);
    };

    const finishClose = () => onClose();

    const toggleVideo = async () => {
        const video = videoRef.current;
        if (!video) return;

        if (video.paused) {
            try {
                await video.play();
                setPlaying(true);
            } catch {}
        } else {
            video.pause();
            setPlaying(false);
        }
    };

    const seekVideo = (e) => {
        const next = Number(e.target.value);
        const video = videoRef.current;
        if (!video || !duration) return;
        video.currentTime = (next / 100) * duration;
        setCurrent(video.currentTime);
    };

    const toggleMute = () => {
        const next = !muted;
        setMuted(next);
        if (videoRef.current) videoRef.current.muted = next;
    };

    return createPortal(
        (
            <div
            className={`media-viewer ${closing ? "media-viewer-closing" : "media-viewer-opening"}`}
            onClick={handleClose}
            onAnimationEnd={(e) => {
                if (closing && e.animationName === "media-viewer-fade-out") finishClose();
            }}
        >
            <button
                type="button"
                onClick={(e) => {
                    e.stopPropagation();
                    handleClose();
                }}
                className="media-viewer-close"
                aria-label="Close media viewer"
            >
                <X size={20} />
            </button>

            {type === "image" ? (
                <div className="media-viewer-stage" onClick={(e) => e.stopPropagation()}>
                    <img
                        src={media.url}
                        alt={media.fileName || "Image"}
                        className="media-viewer-image"
                    />
                </div>
            ) : (
                <div className="media-viewer-stage" onClick={(e) => e.stopPropagation()}>
                    <div className="media-viewer-video-wrap">
                        <video
                            ref={videoRef}
                            src={media.url}
                            preload="metadata"
                            playsInline
                            className="media-viewer-video"
                            onClick={toggleVideo}
                        />

                        {!playing && (
                            <button
                                type="button"
                                onClick={toggleVideo}
                                className="media-viewer-play"
                                aria-label="Play video"
                            >
                                <Play size={27} fill="currentColor" className="ml-1" />
                            </button>
                        )}

                        <div className="media-viewer-controls" onClick={(e) => e.stopPropagation()}>
                            <MediaProgress
                                value={duration ? (current / duration) * 100 : 0}
                                onChange={seekVideo}
                            />
                            <div className="mt-2 flex items-center gap-2">
                                <button
                                    type="button"
                                    onClick={toggleVideo}
                                    className="media-control-button"
                                    aria-label={playing ? "Pause video" : "Play video"}
                                >
                                    {playing ? (
                                        <Pause size={17} fill="currentColor" />
                                    ) : (
                                        <Play size={17} fill="currentColor" className="ml-0.5" />
                                    )}
                                </button>
                                <span className="text-[11px] tabular-nums opacity-85">
                                    {formatDuration(current)}
                                </span>
                                <span className="text-[11px] tabular-nums opacity-45">
                                    / {formatDuration(duration)}
                                </span>
                                <button
                                    type="button"
                                    onClick={toggleMute}
                                    className="media-control-button ml-auto"
                                    aria-label={muted ? "Unmute video" : "Mute video"}
                                >
                                    {muted ? <VolumeX size={17} /> : <Volume2 size={17} />}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
            </div>
        ),
        document.body
    );
}

function StatusIcon({ status, isGroup, seenCount = 0 }) {
    if (status === "read") {
        if (isGroup) {
            return (
                <span className="inline-flex items-center gap-0.5">
                    <UserRound size={11} strokeWidth={2.3} />
                    {seenCount > 0 && <span className="text-[10px] leading-none">{seenCount}</span>}
                </span>
            );
        }
        return <UserRound size={12} strokeWidth={2.3} />;
    }

    if (status === "delivered") {
        return <CheckCheck size={15} strokeWidth={2.5} style={{ opacity: 0.92 }} />;
    }

    return <Check size={14} strokeWidth={2.2} style={{ opacity: 0.7 }} />;
}

export default function MessageBubble({ message, showAuthor, animate, onMenu, onReplyNavigate, searchActive = false, selected = false, selectMode = false, onToggleSelect }) {
    const isMe = message.from === "me";
    const pressTimerRef = useRef(null);
    const pressStartRef = useRef({ x: 0, y: 0 });
    const longPressFiredRef = useRef(false);
    const [viewer, setViewer] = useState(null);
    const isVisualMedia = !message.deleted && (message.type === "image" || message.type === "video") && message.media?.url;

    const openMenu = (x, y) => onMenu?.(message, x, y);

    const handleClick = () => {
        if (selectMode && !message.deleted) onToggleSelect?.(message.id);
    };

    const handleReplyClick = (e) => {
        e.stopPropagation();
        if (message.replyTo?.id) onReplyNavigate?.(message.replyTo.id);
    };

    const handleContextMenu = (e) => {
        e.preventDefault();
        openMenu(e.clientX, e.clientY);
    };

    const clearPressTimer = () => {
        if (pressTimerRef.current) {
            clearTimeout(pressTimerRef.current);
            pressTimerRef.current = null;
        }
    };

    const handleTouchStart = (e) => {
        const touch = e.touches[0];
        pressStartRef.current = { x: touch.clientX, y: touch.clientY };
        longPressFiredRef.current = false;
        clearPressTimer();
        pressTimerRef.current = setTimeout(() => {
            longPressFiredRef.current = true;
            openMenu(touch.clientX, touch.clientY);
        }, LONG_PRESS_MS);
    };

    const handleTouchMove = (e) => {
        const touch = e.touches[0];
        const dx = touch.clientX - pressStartRef.current.x;
        const dy = touch.clientY - pressStartRef.current.y;
        if (Math.hypot(dx, dy) > LONG_PRESS_MOVE_TOLERANCE) clearPressTimer();
    };

    const handleTouchEnd = () => clearPressTimer();

    return (
        <div
            className={`flex ${isMe ? "justify-end" : "justify-start"} ${animate ? "anim-bubble-in" : ""}`}
        >
            <div
                onClick={handleClick}
                onContextMenu={handleContextMenu}
                onTouchStart={handleTouchStart}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
                onTouchCancel={handleTouchEnd}
                className={`${isVisualMedia ? "max-w-[78%] sm:max-w-[65%] p-0 shadow-none" : "max-w-[78%] sm:max-w-[65%] px-3.5 py-2 shadow-[var(--shadow-sm)]"} select-none transition-all duration-200 ${searchActive ? "ring-2 ring-[var(--accent)] ring-offset-2 ring-offset-[var(--bg)]" : ""} ${selected ? "ring-2 ring-[var(--accent)] ring-offset-2 ring-offset-[var(--bg)]" : ""} ${selectMode ? "cursor-pointer" : ""}`}
                style={{
                    background: isVisualMedia ? "transparent" : (isMe ? "var(--bubble-sent)" : "var(--bubble-received)"),
                    color: isMe ? "var(--bubble-sent-text)" : "var(--bubble-received-text)",
                    border: isVisualMedia ? "none" : (isMe ? "none" : "1px solid var(--bubble-received-border)"),
                    borderRadius: isVisualMedia ? 0 : (isMe ? "16px 16px 4px 16px" : "16px 16px 16px 4px"),
                }}
            >
                {message.forwarded && !message.deleted && (
                    <div className="mb-1 text-[11px] font-medium" style={{ color: "var(--accent)" }}>Forwarded</div>
                )}
                {message.replyTo && !message.deleted && (
                    <div
                        onClick={handleReplyClick}
                        role={message.replyTo?.id ? "button" : undefined}
                        tabIndex={message.replyTo?.id ? 0 : undefined}
                        className={`mb-2 flex min-w-0 items-stretch overflow-hidden rounded-[10px] border ${message.replyTo?.id ? "cursor-pointer transition-colors hover:brightness-110" : ""}`}
                        style={{
                            background: isMe
                                ? "color-mix(in srgb, var(--accent-text) 10%, transparent)"
                                : "var(--surface-2)",
                            borderColor: isMe
                                ? "color-mix(in srgb, var(--accent-text) 16%, transparent)"
                                : "var(--border)",
                        }}
                    >
                        <div
                            className="w-0.5 shrink-0"
                            style={{ background: "var(--accent)" }}
                        />

                        <div className="min-w-0 flex-1 px-2.5 py-1.5">
                            <p
                                className="mb-0.5 text-[10.5px] font-semibold leading-tight"
                                style={{
                                    color: isMe
                                        ? "var(--bubble-sent-text)"
                                        : "var(--accent)",
                                    opacity: isMe ? 0.9 : 1,
                                }}
                            >
                                {message.replyTo.from === "me" ? "You" : "Replying to message"}
                            </p>

                            <p
                                className="truncate text-[11.5px] leading-snug"
                                style={{
                                    color: isMe
                                        ? "var(--bubble-sent-text)"
                                        : "var(--text-muted)",
                                    opacity: isMe ? 0.82 : 1,
                                }}
                            >
                                {message.replyTo.text}
                            </p>
                        </div>
                    </div>
                )}
                {showAuthor && message.author && !message.deleted && (
                    <div className="text-[12px] font-medium mb-0.5" style={{ color: "var(--accent)" }}>
                        {message.author}
                    </div>
                )}
                {!message.deleted && message.type === "image" && message.media?.url && (
                    <button
                        type="button"
                        onClick={() => setViewer({ type: "image", media: message.media })}
                        className="media-inline-image"
                        aria-label="Open image"
                    >
                        <img
                            src={message.media.url}
                            alt={message.media.fileName || "Image"}
                            className="media-inline-image-img"
                            loading="lazy"
                        />
                    </button>
                )}

                {!message.deleted && message.type === "video" && message.media?.url && (
                    <button
                        type="button"
                        onClick={() => setViewer({ type: "video", media: message.media })}
                        className="media-inline-video"
                        aria-label="Open video"
                    >
                        <video
                            src={message.media.url}
                            preload="metadata"
                            muted
                            playsInline
                            className="media-inline-video-element"
                        />
                        <span className="media-inline-play">
                            <Play size={20} fill="currentColor" className="ml-0.5" />
                        </span>
                    </button>
                )}

                {!message.deleted && message.type === "audio" && message.media?.url && (
                    <CustomAudioPlayer src={message.media.url} />
                )}

                {!message.deleted && message.type === "file" && message.media?.url && (
                    <a
                        href={message.media.url}
                        download={message.media.fileName || true}
                        target="_blank"
                        rel="noreferrer"
                        className="mb-1 flex min-w-[190px] items-center gap-3 rounded-xl border px-3 py-2.5 transition-colors hover:brightness-110"
                        style={{ borderColor: isMe ? "color-mix(in srgb, var(--bubble-sent-text) 18%, transparent)" : "var(--border)" }}
                    >
                        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg" style={{ background: "var(--surface-2)", color: "var(--accent)" }}>
                            <span className="text-[11px] font-bold">FILE</span>
                        </div>
                        <div className="min-w-0">
                            <p className="truncate text-[12px] font-medium">{message.media.fileName || "File"}</p>
                            <p className="text-[10px] opacity-70">Download</p>
                        </div>
                    </a>
                )}

                {message.type === "text" || !message.type ? null : null}

                {message.deleted ? (
                    <p
                        className="text-[13.5px] italic leading-snug"
                        style={{ color: isMe ? "var(--bubble-sent-text)" : "var(--text-muted)", opacity: 0.75 }}
                    >
                        This message was deleted
                    </p>
                ) : (
                    message.type === "text" || !message.type ? (
                        <p className="text-[14.5px] leading-snug whitespace-pre-wrap break-words">{message.text}</p>
                    ) : null
                )}
                <div
                    className={`${isVisualMedia ? "-mt-9 relative z-10 mr-2 justify-end rounded-full bg-black/55 px-2 py-1 text-white backdrop-blur-sm" : "mt-1"} flex items-center gap-1 text-[11px] ${isMe ? "justify-end" : "justify-start"}`}
                    style={{ color: isMe ? "var(--bubble-sent-text)" : "var(--text-faint)", opacity: isMe ? 0.72 : 1 }}
                >
                    {message.edited && !message.deleted && (
                        <span className="font-medium" style={{ opacity: 0.8 }}>Edited</span>
                    )}
                    <span>{message.time}</span>
                    {isMe && !message.deleted && <StatusIcon status={message.status} isGroup={message.isGroup} seenCount={message.seenCount} />}
                </div>
            </div>
            {viewer && (
                <MediaViewer
                    type={viewer.type}
                    media={viewer.media}
                    onClose={() => setViewer(null)}
                />
            )}
        </div>
    );
}
