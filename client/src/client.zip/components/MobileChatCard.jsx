import Avatar from "./Avatar";

export default function MobileChatCard({ contact, unread, isTyping, lastMessage, onSelect, delay = 0 }) {
    // Use the persisted Conversation.lastMessage when the chat has not been opened yet.
    const displayLastMessage = lastMessage || (contact.lastMessage ? {
        text: contact.lastMessage,
        time: contact.lastMessageTime,
        from: contact.lastMessageFromMe ? "me" : "them",
    } : null);
    return (
        <button
            onClick={() => onSelect(contact.id)}
            className="anim-pop-in flex w-full items-center gap-3 rounded-3xl px-3.5 py-3 text-left transition-transform active:scale-[0.98]"
            style={{ background: "var(--surface)", boxShadow: "var(--shadow-sm)", animationDelay: `${delay}ms` }}
        >
            <Avatar name={contact.name} initials={contact.initials} src={contact.avatar} color={contact.color} size="md" />

            <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between gap-2">
                    <p className="truncate text-[14.5px] font-semibold" style={{ color: "var(--text)" }}>
                        {contact.name}
                    </p>
                    {displayLastMessage && (
                        <span className="shrink-0 text-[11px]" style={{ color: "var(--text-faint)" }}>
                            {displayLastMessage.time}
                        </span>
                    )}
                </div>
                <div className="mt-0.5 flex items-center justify-between gap-2">
                    <p
                        className="truncate text-[13px]"
                        style={{ color: isTyping ? "var(--accent)" : "var(--text-muted)" }}
                    >
                        {isTyping
                            ? "typing…"
                            : displayLastMessage
                                ? `${displayLastMessage.from === "me" ? "You: " : ""}${displayLastMessage.text}`
                                : "No messages yet"}
                    </p>
                    {unread > 0 && (
                        <span
                            className="grid h-5 min-w-5 shrink-0 place-items-center rounded-full px-1 text-[10.5px] font-semibold"
                            style={{ background: "var(--accent)", color: "var(--accent-text)" }}
                        >
                            {unread}
                        </span>
                    )}
                </div>
            </div>
        </button>
    );
}
