import Avatar from "./Avatar";

export default function ChatCard({ contact, unread, isTyping, lastMessage, onSelect, onContextMenu, delay = 0, active = false }) {
    // Chat list can be rendered before this conversation is opened, so the
    // in-memory messages array may be empty. Fall back to the persisted
    // Conversation.lastMessage supplied by GET /conversations.
    const displayLastMessage = lastMessage || (contact.lastMessage ? {
        text: contact.lastMessage,
        time: contact.lastMessageTime,
        from: contact.lastMessageFromMe ? "me" : "them",
    } : null);
    return (
        <button
            onClick={() => onSelect(contact.id)}
            onContextMenu={(event) => {
                event.preventDefault();
                onContextMenu?.(event, contact);
            }}
            className="anim-pop-in flex w-full items-center gap-3 rounded-3xl px-3.5 py-3 text-left transition-transform active:scale-[0.98]"
            style={{
                background: active ? "var(--accent-soft)" : "var(--surface)",
                boxShadow: active ? "none" : "var(--shadow-sm)",
                border: active ? "1px solid var(--accent)" : "1px solid transparent",
                animationDelay: `${delay}ms`,
            }}
        >

            <Avatar name={contact.name} initials={contact.initials} src={contact.avatar} color={contact.color} size="md" />

            <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between gap-2">
                    <p className="truncate text-[14.5px] font-semibold" style={{ color: "var(--text)" }}>
                        {contact.name}
                    </p>
                    {displayLastMessage && (
                        <span className="shrink-0 text-[11px]" style={{ color: "var(--text-faint)" }}>
                            {displayLastMessage.time}
                        </span>
                    )}
                </div>
                <div className="mt-0.5 flex items-center justify-between gap-2">
                    <p
                        className="truncate text-[13px]"
                        style={{ color: isTyping ? "var(--accent)" : "var(--text-muted)" }}
                    >
                        {isTyping
                            ? "typing…"
                            : displayLastMessage
                                ? `${displayLastMessage.from === "me" ? "You: " : ""}${displayLastMessage.text}`
                                : "No messages yet"}
                    </p>
                    {unread > 0 && (
                        <span
                            className="grid h-5 min-w-5 shrink-0 place-items-center rounded-full px-1 text-[10.5px] font-semibold"
                            style={{ background: "var(--accent)", color: "var(--accent-text)" }}
                        >
                            {unread}
                        </span>
                    )}
                </div>
            </div>
        </button>
    );
}
